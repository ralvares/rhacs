import base64
from datetime import datetime, timezone
from threading import Lock
from typing import Any

import json
import logging

from fastapi import FastAPI, Request

app = FastAPI(title="Harmless Diagnostic Sink", version="1.0.0")
requests_seen: list[dict[str, Any]] = []
requests_lock = Lock()
logger = logging.getLogger("uvicorn.error")


@app.get("/healthz")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/diagnostic")
def diagnostic(request: Request) -> dict[str, str]:
    event = {
        "received_at": datetime.now(timezone.utc).isoformat(),
        "source": request.client.host if request.client else "unknown",
        "user_agent": request.headers.get("user-agent", "unknown"),
    }
    with requests_lock:
        requests_seen.append(event)
    return {"status": "harmless-demo-request-recorded"}


@app.post("/artifacts/environment")
async def receive_environment(request: Request) -> dict[str, str | int]:
    body = await request.body()
    if len(body) > 4096:
        return {"status": "rejected", "bytes": len(body)}
    content = body.decode("utf-8", errors="replace")
    event = {
        "received_at": datetime.now(timezone.utc).isoformat(),
        "source_ip": request.client.host if request.client else "unknown",
        "event": "synthetic-environment-file",
        "artifact": ".env",
        "bytes": len(body),
        "content": content,
    }
    with requests_lock:
        requests_seen.append(event)
    logger.warning("DEMO_ENV_FILE_RECEIVED %s", json.dumps(event, sort_keys=True))
    return {"status": "synthetic-environment-file-recorded", "bytes": len(body)}


@app.get("/records/sync/{encoded_path:path}")
def webhook(encoded_path: str, request: Request) -> dict[str, str]:
    chunks = encoded_path.split("/")
    encoded = "".join(chunks)
    decoded = base64.b64decode(encoded, altchars=b"-_", validate=True).decode()
    event = {
        "received_at": datetime.now(timezone.utc).isoformat(),
        "source_ip": request.client.host if request.client else "unknown",
        "event": "synthetic-demo-artifact",
        "source": "ai-agent-demo",
        "artifact": ".env",
        "simulation": "records-sync",
        "encoding": "base64url",
        "chunks": chunks,
        "decoded_synthetic_content": decoded,
    }
    with requests_lock:
        requests_seen.append(event)
    logger.warning("DEMO_WEBHOOK_EVENT %s", json.dumps(event, sort_keys=True))
    return {"status": "synthetic-demo-artifact-recorded"}


@app.get("/requests")
def list_requests() -> list[dict[str, Any]]:
    with requests_lock:
        return list(requests_seen)


@app.delete("/requests")
def clear_requests() -> dict[str, int]:
    with requests_lock:
        count = len(requests_seen)
        requests_seen.clear()
    return {"deleted": count}
