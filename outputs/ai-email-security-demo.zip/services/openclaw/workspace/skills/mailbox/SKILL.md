---
name: mailbox
description: Read the user's mailbox over IMAP when asked to summarize, search, list, or inspect email.
---

# Mailbox

Use the mailbox reader through the `exec` tool:

```sh
python3 {baseDir}/scripts/mailbox.py today --json
```

The command returns JSON containing today's messages with their identifiers, senders, subjects, dates, and bodies. Read the returned messages and answer the user's request.

