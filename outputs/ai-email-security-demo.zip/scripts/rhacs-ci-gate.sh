#!/usr/bin/env sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
work_dir="$repo_dir/.work/rhacs"

command -v oc >/dev/null 2>&1 || { echo "oc is required" >&2; exit 1; }
command -v roxctl >/dev/null 2>&1 || { echo "roxctl is required" >&2; exit 1; }
: "${ROX_ENDPOINT:?Set ROX_ENDPOINT for RHACS Central}"
: "${ROX_API_TOKEN:?Set ROX_API_TOKEN to a RHACS CI token}"

registry_host=$(oc -n openshift-image-registry get route default-route -o jsonpath='{.spec.host}' 2>/dev/null || true)
[ -n "$registry_host" ] || { echo "OpenShift internal registry Route is required" >&2; exit 2; }
v1="$registry_host/ai-email-demo/ai-agent:v1"
v2="$registry_host/ai-email-demo/ai-agent:v2"

mkdir -p "$work_dir"
sed "s#REGISTRY_ROUTE#$registry_host#g" "$repo_dir/deploy/rhacs/bad-ai-agent.yaml" > "$work_dir/v1-bad.yaml"
sed "s#REGISTRY_ROUTE#$registry_host#g" "$repo_dir/deploy/rhacs/clean-ai-agent.yaml" > "$work_dir/v2-clean.yaml"

echo "[1/6] Scan deliberately obsolete v1 components and vulnerabilities"
roxctl image scan --image "$v1" --force -o table || true

echo "[2/6] Confirm RHACS rejects v1 image policy"
if roxctl image check --image "$v1" --force -o table; then
  echo "ERROR: v1 passed. Enable the intended vulnerability and trusted-signer policies in RHACS." >&2
  exit 1
fi

echo "[3/6] Confirm RHACS rejects the privileged v1 Deployment"
if roxctl deployment check --file "$work_dir/v1-bad.yaml" -o table; then
  echo "ERROR: privileged v1 Deployment unexpectedly passed." >&2
  exit 1
fi

echo "[4/6] Scan the current hardened v2 image"
roxctl image scan --image "$v2" --force -o table

echo "[5/6] Require v2 to satisfy image policies, including trusted signature"
roxctl image check --image "$v2" --force -o table

echo "[6/6] Require the hardened v2 Deployment to satisfy deploy-time policies"
roxctl deployment check --file "$work_dir/v2-clean.yaml" -o table

echo "RHACS CI/CD gate passed for signed v2 and rejected v1."
