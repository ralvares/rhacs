#!/usr/bin/env sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
platform=${1:-}
if [ -f "$repo_dir/.env" ]; then
  set -a
  # This is the operator-owned local configuration file.
  . "$repo_dir/.env"
  set +a
fi
usage() {
  echo "usage:" >&2
  echo "  $0 openshift" >&2
  echo "  $0 kubernetes REGISTRY/PROJECT DOMAIN [INGRESS_CLASS]" >&2
  exit 2
}

apply_base() {
  cli=$1
  replacement=$2
  for manifest in "$repo_dir"/deploy/base/*.yaml; do
    sed \
      -e "s#IMAGE_REGISTRY/ai-email-demo#$replacement#g" \
      "$manifest" | "$cli" apply -f -
  done
}

apply_runtime_secrets() {
  cli=$1
  command -v openssl >/dev/null 2>&1 || { echo "openssl is required to generate demo credentials" >&2; exit 1; }
  mail_user=${DEMO_MAIL_USER:-demo}
  mail_password=${DEMO_MAIL_PASSWORD:-demo}
  mail_domain=${DEMO_MAIL_DOMAIN:-demo.test}
  mail_address="${mail_user}@${mail_domain}"
  demo_context_id=$(openssl rand -hex 6)
  gateway_token=$(openssl rand -hex 24)
  demo_runtime_context="DEMO_API_KEY=synthetic-${demo_context_id}
DEMO_REGION=lab-only"
  greenmail_opts="-Dgreenmail.setup.test.smtp -Dgreenmail.setup.test.imap -Dgreenmail.hostname=0.0.0.0 -Dgreenmail.users=${mail_user}:${mail_password}@${mail_domain} -Dgreenmail.users.login=username"
  "$cli" -n ai-email-demo create secret generic mail-credentials \
    --from-literal=mail-user="$mail_user" \
    --from-literal=mail-password="$mail_password" \
    --from-literal=mail-address="$mail_address" \
    --from-literal=greenmail-opts="$greenmail_opts" \
    --dry-run=client -o yaml | "$cli" apply -f -
  "$cli" -n ai-email-demo create secret generic demo-runtime-context \
    --from-literal=runtime-context="$demo_runtime_context" \
    --dry-run=client -o yaml | "$cli" apply -f -
  "$cli" -n ai-email-demo create secret generic openclaw-credentials \
    --from-literal=gateway-token="$gateway_token" \
    --dry-run=client -o yaml | "$cli" apply -f -
}

if [ "$platform" = "openshift" ]; then
  command -v oc >/dev/null 2>&1 || { echo "oc is required" >&2; exit 1; }
  oc apply -f "$repo_dir/deploy/base/00-namespace.yaml"
  apply_runtime_secrets oc
  oc apply -f "$repo_dir/deploy/openshift/buildconfigs.yaml"
  oc -n ai-email-demo start-build mail-api --from-dir="$repo_dir/services/mail-api" --follow --wait
  oc -n ai-email-demo start-build ai-agent-v1 --from-dir="$repo_dir/services/ai-agent" --follow --wait
  oc -n ai-email-demo start-build ai-agent-v2 --from-dir="$repo_dir/services/openclaw" --follow --wait
  oc -n ai-email-demo tag ai-agent:v2 ai-agent:latest
  oc -n ai-email-demo start-build demo-sink --from-dir="$repo_dir/services/unauthorized-demo-service" --follow --wait
  apply_base oc "image-registry.openshift-image-registry.svc:5000/ai-email-demo"
  oc -n ai-email-demo rollout restart deployment/mail-server deployment/mail-api deployment/ai-agent
  oc apply -f "$repo_dir/deploy/openshift/routes.yaml"
  oc -n ai-email-demo delete networkpolicy ai-agent-egress-after --ignore-not-found
  oc apply -f "$repo_dir/deploy/network-policy/before-permissive.yaml"
  oc -n ai-email-demo rollout status deployment/mail-server --timeout=180s
  oc -n ai-email-demo rollout status deployment/webmail --timeout=180s
  oc -n ai-email-demo rollout status deployment/mail-api --timeout=180s
  oc -n ai-email-demo rollout status deployment/ai-agent --timeout=180s
  oc -n ai-email-demo rollout status deployment/unauthorized-demo-service --timeout=180s
  "$repo_dir/scripts/setup-external-demo.sh"
  echo "Checking OpenClaw's native Ollama connection..."
  oc -n ai-email-demo exec deployment/ai-agent -- node openclaw.mjs models list --provider ollama
  echo "Creating the demo mailbox and normal messages..."
  curl --fail --silent --show-error -X POST "https://$(oc -n ai-email-demo get route mail-api -o jsonpath='{.spec.host}')/seed"
  echo "Running an end-to-end chatbot smoke test..."
  oc -n ai-email-demo exec deployment/ai-agent -- node openclaw.mjs agent --agent main --message "Summarize today's email" --json
  echo "OpenShift demo is ready."
  oc -n ai-email-demo get routes
  echo "Show presentation credentials with: ./scripts/show-demo-credentials.sh"
elif [ "$platform" = "kubernetes" ]; then
  [ "$#" -ge 3 ] || usage
  command -v kubectl >/dev/null 2>&1 || { echo "kubectl is required" >&2; exit 1; }
  registry=${2%/}
  domain=$3
  ingress_class=${4:-nginx}
  kubectl apply -f "$repo_dir/deploy/base/00-namespace.yaml"
  apply_runtime_secrets kubectl
  apply_base kubectl "$registry"
  kubectl -n ai-email-demo rollout restart deployment/mail-server deployment/mail-api deployment/ai-agent
  sed \
    -e "s/INGRESS_CLASS/$ingress_class/g" \
    -e "s/WEBMAIL_HOST/webmail.$domain/g" \
    -e "s/MAIL_API_HOST/mail-api.$domain/g" \
    -e "s/AI_AGENT_HOST/ai-agent.$domain/g" \
    "$repo_dir/deploy/kubernetes/ingress.yaml" | kubectl apply -f -
  kubectl -n ai-email-demo delete networkpolicy ai-agent-egress-after --ignore-not-found
  kubectl apply -f "$repo_dir/deploy/network-policy/before-permissive.yaml"
  kubectl -n ai-email-demo rollout status deployment/mail-server --timeout=180s
  kubectl -n ai-email-demo rollout status deployment/webmail --timeout=180s
  kubectl -n ai-email-demo rollout status deployment/mail-api --timeout=180s
  kubectl -n ai-email-demo rollout status deployment/ai-agent --timeout=180s
  kubectl -n ai-email-demo rollout status deployment/unauthorized-demo-service --timeout=180s
  echo "Kubernetes demo is ready at webmail.$domain, mail-api.$domain, and ai-agent.$domain"
else
  usage
fi
