#!/usr/bin/env sh
set -eu

repo_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
work_dir="$repo_dir/.work/cosign"
auth_file="$work_dir/auth.json"
key_prefix="$work_dir/rhacs-demo"

command -v oc >/dev/null 2>&1 || { echo "oc is required" >&2; exit 1; }
command -v cosign >/dev/null 2>&1 || { echo "cosign is required" >&2; exit 1; }
"$repo_dir/scripts/generate-signing-key.sh"

registry_host=$(oc -n openshift-image-registry get route default-route -o jsonpath='{.spec.host}' 2>/dev/null || true)
[ -n "$registry_host" ] || {
  echo "The OpenShift image-registry default Route is not enabled." >&2
  echo "A cluster administrator can enable it with:" >&2
  echo "  oc patch configs.imageregistry.operator.openshift.io/cluster --type=merge -p '{\"spec\":{\"defaultRoute\":true}}'" >&2
  exit 2
}

digest=$(oc -n ai-email-demo get istag ai-agent:v2 -o jsonpath='{.image.metadata.name}')
[ -n "$digest" ] || { echo "ai-agent:v2 has no image digest; run setup first" >&2; exit 2; }
image="$registry_host/ai-email-demo/ai-agent@$digest"

COSIGN_PASSWORD=$(cat "$work_dir/password")
export COSIGN_PASSWORD

oc registry login --registry "$registry_host" --to "$auth_file" --insecure=true
export REGISTRY_AUTH_FILE="$auth_file"
cosign sign --yes --tlog-upload=false --allow-insecure-registry \
  --key "$key_prefix.key" -a release=v2 -a purpose=rhacs-ai-demo "$image"
cosign verify --allow-insecure-registry --insecure-ignore-tlog=true \
  --key "$key_prefix.pub" "$image"

printf 'Signed image: %s\n' "$image"
printf 'RHACS public key: %s.pub\n' "$key_prefix"
printf 'Private signing material remains under ignored path: %s\n' "$work_dir"
