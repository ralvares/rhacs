#!/usr/bin/env sh
set -eu

cli=${CLI:-}
if [ -z "$cli" ]; then
  if command -v oc >/dev/null 2>&1 && oc api-resources --api-group=route.openshift.io 2>/dev/null | grep -q routes; then
    cli=oc
  else
    cli=kubectl
  fi
fi

password=$($cli -n ai-email-demo get secret mail-credentials -o go-template='{{index .data "mail-password" | base64decode}}')
mail_user=$($cli -n ai-email-demo get secret mail-credentials -o go-template='{{index .data "mail-user" | base64decode}}')
mail_address=$($cli -n ai-email-demo get secret mail-credentials -o go-template='{{index .data "mail-address" | base64decode}}')
gateway_token=$($cli -n ai-email-demo get secret openclaw-credentials -o go-template='{{index .data "gateway-token" | base64decode}}')
printf 'Webmail user: %s\nWebmail password: %s\nMailbox address: %s\nOpenClaw gateway token: %s\n' "$mail_user" "$password" "$mail_address" "$gateway_token"

if [ "${1:-}" != "--approve" ]; then
  printf '\nIf the browser requests pairing, click Connect once and run:\n  %s --approve\n' "$0"
  exit 0
fi

# The Control UI creates a pairing request only after the browser has tried to
# connect once with the gateway token. OpenClaw requires approval by an exact
# request ID, so resolve the newest pending request and approve it explicitly.
devices=$($cli -n ai-email-demo exec -c openclaw deployment/ai-agent -- \
  node openclaw.mjs devices list --json)
request_id=$(printf '%s' "$devices" | python3 -c \
  'import json, sys; pending=json.load(sys.stdin).get("pending", []); print(pending[-1]["requestId"] if pending else "")')

if [ -n "$request_id" ]; then
  $cli -n ai-email-demo exec -c openclaw deployment/ai-agent -- \
    node openclaw.mjs devices approve "$request_id" --json >/dev/null
  printf '\nOpenClaw browser device approved. Click Connect again.\n'
else
  printf '\nNo pending OpenClaw browser request. In the browser, put the token in Gateway Token, click Connect once, then rerun this command with --approve.\n'
fi
