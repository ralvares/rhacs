# Speaker notes: securing AI workloads from code to cluster

## How to use these notes

These notes follow the 16-slide sequence in `PRESENTATION-STORY.md`. They are written for a 35–45 minute session:

- 15–20 minutes for the problem and product story;
- 10–15 minutes for the live demonstration;
- 5 minutes for conclusions and questions.

For a shorter session, use only the paragraph labeled **Core talk track** on each slide. For a technical audience, add the **Technical depth** paragraph. For leadership, use the **Business translation** paragraph.

Do not read the slide. Use it as visual evidence while the notes carry the story.

Immediately before the audience arrives, prepare the clean base state:

```sh
./scripts/setup-demo.sh
```

This applies the configured mailbox login and resets previous conversations, but it does not call the model or send the injected message. Reapprove the browser only if requested. From that point forward, ask every chatbot question manually in the browser and use only the sender and containment scripts as live triggers.

## Opening before slide 1

Walk on with the normal email-agent chatbot already open, but do not explain its implementation yet.

Suggested opening:

> “When we say AI security, where does your mind go first? Usually to the model: prompt injection, jailbreaks, poisoned training data, or information leaking through a prompt. Those risks are real—but they are only one layer.”

Pause, then broaden the frame:

> “The model does not arrive alone. It is called by application code. That code uses open-source libraries and an agent framework. It runs in a base image, is produced by a pipeline, receives credentials and identity, invokes tools, reads data, and communicates over a network. An AI workload inherits every traditional software-supply-chain and cloud-native risk—and then adds probabilistic decisions and autonomous actions on top.”

Use the additive model:

```text
AI security is not:
    model security only

AI workload security is:
    inherited software and platform risk
    + model, data, prompt, retrieval, and tool risk
```

Then connect risk to consequence:

> “Prompt injection may explain why a model made a decision. But the impact depends on ordinary controls: which package was vulnerable, which file the container could read, which credential it held, which process it could start, which identity it had, and which destination the network allowed it to reach.”

Now pose the session question:

> “So how do we preserve AI delivery speed while maintaining evidence and control from the developer's first dependency choice all the way to production behavior?”

Answer with the session promise:

> “Today I will follow one AI workload from workstation to pipeline, SBOM, signed artifact, admission, runtime observation, and containment.”

Pause, then set the expectation:

> “This is not a claim that one product solves AI security. It is a story about connected controls, clear ownership, and evidence that follows the workload.”

### Opening visual guidance

Start with two columns:

```text
What people first think about        What the AI workload also inherits

Prompt injection                     Open-source package vulnerabilities
Jailbreaks                            Compromised build or base image
Model poisoning                       Misconfigured containers
Sensitive prompt data                 Secrets and excessive identity
Model safety                          Child processes and network reach
```

Reveal the right column after discussing the left. Then place “AI workload security” across both columns.

### Opening persona connection

- Developers own dependency and application choices.
- AI engineers own model, retrieval, and tool design.
- Platform teams own the paved path and workload defaults.
- AppSec owns policy and risk guidance.
- SecOps owns investigation and response.
- Risk and compliance teams need durable composition and provenance evidence.

Say:

> “The point is not to move AI security away from the AI team. It is to connect the AI team to every other role that already secures production software.”

## Slide 1 — AI workloads move fast—and inherit everything

### Purpose

Expand the audience's mental model from “AI equals model” to “AI equals a complete software and infrastructure supply chain.”

### Core talk track

> “When teams say they are building an AI application, they usually begin with the model. But the model is surrounded by ordinary software: open-source libraries, an agent framework, plugins or tools, a model client, a container base image, and cloud-native infrastructure. Every one of those components brings provenance, vulnerability, configuration, identity, and runtime questions.”

> “AI increases the importance of those questions because the workload can convert natural-language input into actions. A vulnerable library is still a vulnerable library—but now the application may also choose when to invoke a tool, which file to read, or which service to contact.”

Add the central contrast:

> “Prompt injection is important, but prompt injection is not the whole system. It is one possible influence on a decision. The blast radius is determined by the conventional software and infrastructure authority surrounding that decision.”

### Business translation

> “The risk is not that open source is bad. Open source makes this innovation possible. The risk is losing visibility while composition and delivery speed increase.”

### Persona cues

- Developer: many indirect dependencies arrive with one package choice.
- Platform engineer: every team should not assemble this stack differently.
- Security leader: the attack surface includes software, delivery, identity, tools, and runtime.

### Transition

> “If the workload spans all of these layers, no single checkpoint can secure it. We need to follow its lifecycle.”

## Slide 2 — No single control answers every question

### Purpose

Introduce layered control ownership without creating a product list too early.

### Core talk track

> “At the workstation, the question is whether we should introduce a dependency. In the pipeline, the question is whether we can build and test consistently. For the artifact, we need composition and provenance. At admission, we need policy. At runtime, we need to know what actually executed and where it communicated. At the AI layer, we need to decide whether content is allowed to authorize an action.”

> “These questions are connected, but they are not interchangeable. An SBOM cannot tell us whether an email should invoke a tool. A runtime process event cannot tell us whether an artifact was built by an approved pipeline. A signature proves identity and integrity, not benign future behavior.”

### Technical depth

Use this control distinction:

```text
composition != provenance
provenance  != policy compliance
compliance  != runtime intent
telemetry   != semantic authorization
```

### Transition

> “So let us start at the earliest and cheapest decision point: the developer workstation.”

## Slide 3 — Red Hat Dependency Analytics

### Purpose

Show that supply-chain security begins before the container exists.

### Core talk track

> “A developer is about to add a package. This is the moment with the lowest remediation cost: no image has been built, no pipeline has failed, and nothing has reached a cluster. Red Hat Dependency Analytics brings vulnerability and dependency intelligence into that workflow.”

> “The objective is not to ask every developer to become a vulnerability researcher. It is to give them relevant evidence while the decision is still easy to change.”

### Technical depth

> “For this demonstration, v1 contains deliberately obsolete Python package pins so that the finding is stable. The real v2 application is Node-based and inherits a larger npm/pnpm tree from its agent-runtime image. That contrast lets us discuss direct dependencies, transitive dependencies, and inherited image content.”

Current capabilities worth mentioning include workspace/package analysis, CycloneDX SBOM generation, and Dockerfile analysis. Avoid promising identical language/ecosystem behavior without verifying the installed extension version.

### Persona cues

- Developer: actionable information before commit or build.
- AppSec: policy and guidance closer to the source of the decision.
- Leadership: less rework and fewer late-stage pipeline failures.

### Transition

> “The developer can make a better choice—but once we build, we need a durable inventory of what the artifact actually contains.”

## Slide 4 — SBOM: the ingredient list for software

### Purpose

Explain SBOMs without treating them as a magic security score.

### Core talk track

> “A Software Bill of Materials is a machine-readable inventory of components and relationships associated with a software artifact. Think of it as an ingredient list—but an ingredient list designed for automation.”

> “It can identify package names, versions, package URLs, dependency relationships, licenses, suppliers, and hashes when that information is available. The important point is not the document by itself. The value comes from binding it to the right artifact and continuously correlating it with changing vulnerability intelligence.”

### Explain the boundary

> “An SBOM does not say that the software is safe. It says what we know is inside. It does not prove who built the artifact—that is provenance and signing. It does not describe what the workload did yesterday—that is runtime telemetry.”

### AI-specific distinction

> “A container SBOM describes the software in the image. Our DeepSeek model is remote, so it would be incorrect to pretend the model is automatically part of that image SBOM. AI-specific and cryptographic inventories can complement the software SBOM when those assets are in scope.”

### Audience check

Ask:

> “If a critical npm vulnerability is published tomorrow, can you identify every AI workload that contains the affected version?”

Then answer:

> “That is the operational value of an accurate, searchable inventory.”

### Transition

> “Now we need a delivery system that creates this evidence consistently instead of asking every team to assemble it manually.”

## Slide 5 — RHTAP: a trusted path from idea to production

### Purpose

Introduce RHTAP as the secure software factory and paved road.

### Core talk track

> “Red Hat Trusted Application Pipeline is the framework that connects project creation, source control, CI/CD, security checks, evidence, and promotion. The value is repeatability: a team starts from a secure template and receives a working delivery path rather than a list of security tasks to integrate later.”

> “The pipeline can build and test, generate SBOMs, run vulnerability checks, create signatures and attestations, evaluate policy, and promote through GitOps. Security evidence becomes an output of normal delivery.”

### Business translation

> “The paved road is how we scale. We reduce both security variance and the cognitive load placed on product teams.”

### Persona cues

- Developer: faster onboarding and fewer bespoke pipeline decisions.
- Platform engineer: standardized templates and reusable controls.
- Security: consistent evidence and gates.
- Compliance: traceable promotion decisions.

### Avoid

Do not describe RHTAP as one scanner. It is an integrated DevSecOps framework and uses specialized products for specific evidence and decisions.

### Transition

> “That distinction matters, so let us look at how the components cooperate inside the trusted path.”

## Slide 6 — The pipeline connects evidence and decisions

### Purpose

Explain product complementarity and prevent ownership confusion.

### Core talk track

> “RHTAP orchestrates the journey. Red Hat Developer Hub provides the self-service entry point. The pipeline builds and tests. Red Hat Trusted Profile Analyzer manages composition knowledge. Red Hat Trusted Artifact Signer establishes signatures and attestations. RHACS scans and evaluates the Kubernetes workload. Enterprise Contract evaluates whether the combined evidence satisfies promotion policy. GitOps carries the approved desired state forward.”

> “None of these products becomes less important because another one exists. Their value increases when the evidence is connected.”

### Technical depth

Walk the arrows, not the boxes:

1. template creates source and pipeline;
2. commit triggers build;
3. build produces image and evidence;
4. SBOM moves to composition analysis;
5. image moves to scanning;
6. digest receives signing and attestation;
7. Enterprise Contract evaluates evidence;
8. GitOps promotes the approved state.

### Transition

> “Let us zoom into the component that turns an SBOM from a file into something the organization can query.”

## Slide 7 — RHTPA: from SBOM files to supply-chain knowledge

### Purpose

Explain RHTPA's ongoing value after SBOM generation.

### Core talk track

> “Red Hat Trusted Profile Analyzer ingests and analyzes SBOM data and correlates packages with vulnerability and advisory information. This is the difference between storing an SBOM as a release attachment and operating an SBOM program.”

> “When a new vulnerability appears, the question is no longer ‘Do we have an SBOM somewhere?’ It becomes ‘Which products contain this package, which versions are affected, and which artifacts should we prioritize?’”

### Use cases

- incident response to a new open-source vulnerability;
- product/version impact analysis;
- audit and compliance evidence;
- component reuse and concentration risk;
- standard SBOM, AIBOM, and CBOM analysis where applicable.

### Boundary

> “RHTPA provides composition and risk knowledge. It does not observe Linux processes inside a running pod. That is where the workload-security view begins.”

### Transition

> “Our artifact now has composition, provenance, and policy evidence. Next, it has to become a Kubernetes workload.”

## Slide 8 — RHACS across build, deploy, and runtime

### Purpose

Introduce RHACS through lifecycle questions rather than a feature inventory.

### Core talk track

> “RHACS protects Kubernetes-native workloads across three stages. At build time, it scans the image and evaluates vulnerability policy. At deploy time, it evaluates Kubernetes configuration and admission policy. At runtime, it provides context about deployments, processes, and network communication, with response based on configured policies.”

### Demo mapping

> “Our v1 image is the deterministic failure. Our bad manifest is deliberately privileged. The v2 path is the real AI workload. At runtime, we will observe two child processes and a network flow that did not exist in the normal baseline.”

### Product boundary

> “RHACS is not reading the mailbox. It does not need to understand the language in an email to tell us that a container started `curl` and contacted another namespace.”

### Persona cues

- AppSec: enforce before deployment.
- Platform security: cluster-wide posture and admission.
- SecOps: investigate runtime context.
- Workload owner: trace the finding back to deployment and image.

### Transition

> “We can now put the products on one lifecycle and show precisely where each one contributes.”

## Slide 9 — One lifecycle, different control owners

### Purpose

Summarize the product story before introducing the application.

### Core talk track

> “Dependency Analytics helps the developer choose. RHTAP creates the trusted delivery path. RHTPA records and analyzes what is inside. RHTAS establishes artifact trust. RHACS controls what reaches the cluster and observes what it does there. OpenShift supplies the execution, identity, and network boundary. Application controls decide whether an AI action is authorized.”

Pause after this sentence. It is the anchor for the presentation.

### Business translation

> “This is defense in depth without duplication. Each control produces evidence or enforces a decision at the layer where it has the strongest context.”

### Transition

> “Now that we have the lifecycle, let us apply it to one small but realistic AI workload.”

## Slide 10 — A personal email agent on OpenShift

### Purpose

Introduce only the application behavior required to understand the demo.

### Core talk track

> “The user has a browser-based personal agent and asks it to summarize today's mailbox. The application reads a real IMAP inbox and calls a remote, tool-capable model. It runs inside OpenShift as a normal containerized workload.”

> “The agent has general capabilities. It can read workspace files and execute a command. Those capabilities are not inherently malicious. One is used to load a mailbox skill, and one is used to run the IMAP helper.”

### Implementation detail, only if asked

- OpenClaw is the selected agent runtime.
- GreenMail supplies SMTP/IMAP.
- Roundcube is the human webmail UI.
- DeepSeek is reached through the workstation's Ollama API.

Do not spend presentation time teaching these products. They exist to make the AI workload believable.

### Transition

> “Before we interact with it, let us establish why we trusted this workload enough to deploy it.”

## Slide 11 — Before runtime: what are we about to trust?

### Purpose

Connect the abstract product story to prepared evidence.

### Core talk track

> “At the workstation, we inspect dependencies. The pipeline builds the images. We produce an SBOM and provenance. RHTPA makes composition searchable. RHACS scans the final image and checks the manifest. RHTAS signs the immutable digest. Policy decides whether the artifact can progress.”

Show prepared views rather than typing commands:

1. Dependency Analytics finding for v1.
2. SBOM/RHTPA composition view.
3. RHACS v1 image finding.
4. Bad privileged manifest rejection.
5. v2 image and clean manifest.
6. Signature/admission evidence.

### Key sentence

> “At this point, the controls have done their jobs. We know what we built, where it came from, and whether it satisfied our release policy.”

### Transition

> “Now I will change none of those things. I will send an email.”

## Slide 12 — The artifact remains trusted; the input changes

### Purpose

Create the pivotal moment of the talk.

### Delivery

Slow down and read the unchanged list:

> “Code: unchanged. Image: unchanged. SBOM: unchanged. Signature: unchanged. Deployment: unchanged. Model: unchanged. User request: unchanged.”

Then reveal:

> “Mailbox content: changed.”

### Core talk track

> “This is why runtime matters. Build-time security was not bypassed and it was not wrong. The artifact is still the artifact we approved. A new piece of untrusted business data has entered a workload that can turn language into actions.”

### Live action

Run only:

```sh
./scripts/send-external-html-email.sh
```

Show the new message in Roundcube. Avoid exposing the alternate machine-consumed content at this moment; let the runtime evidence reveal the consequence.

### Transition

> “The user will now do exactly what they did before.”

## Slide 13 — From untrusted content to workload behavior

### Purpose

Show the runtime consequence without overstating semantic detection.

### Live action

In a fresh chatbot conversation, ask:

```text
Summarize today's email.
```

Show the normal Markdown answer first.

Then switch to evidence:

1. receiver event with synthetic content;
2. RHACS process activity showing `python3` and `curl`;
3. Network Graph showing `ai-email-demo/ai-agent` to `demo-webhook/demo-webhook` on TCP 8080.

### Core talk track

> “The chatbot answer looks normal. But the workload also created a process and a network connection the user did not request. RHACS did not classify the email as malicious. It observed the infrastructure consequence: this workload started `curl` and communicated with a new destination.”

### Precise explanation

> “This is capability abuse through indirect prompt injection. It is not an OpenClaw remote-code-execution vulnerability, a container escape, or a compromised model service.”

### Transition

> “Detection gives us evidence. The next question is why this workload had the network authority to complete that action.”

## Slide 14 — Assume an autonomous workload can make a wrong decision

### Purpose

Move from visibility to blast-radius reduction.

### Core talk track

> “The agent requires DNS, IMAP, and its model endpoint. It may require a small set of approved services. It does not require arbitrary cross-namespace egress. The network policy should express that intended architecture.”

### Live action

Run:

```sh
./scripts/restrict-egress.sh
```

Clear receiver evidence and repeat the same chatbot request.

Show:

- the core application still functions;
- the process attempt may still exist;
- the receiver remains empty;
- the disallowed flow cannot complete.

### Product boundary

> “RHACS provides workload and flow context. OpenShift networking enforces this packet boundary. The application team must still repair the authorization decision. Containment is not semantic remediation.”

### Key sentence

> “We have not made the model infallible. We have made one wrong decision less expensive.”

### Transition

> “Let us close by translating that evidence back to every role involved.”

## Slide 15 — One evidence chain, different decisions

### Purpose

Make the session relevant to multiple personas and enable organizational action.

### Core talk track

> “The developer sees a dependency decision. The platform team sees a paved road. AppSec sees policy evidence. SecOps sees runtime behavior. Compliance sees composition and provenance. The AI engineer sees a trust-boundary failure. Leadership sees a way to scale AI delivery without surrendering control.”

### Facilitation prompt

Ask the audience:

> “Who owns the decision that email content may invoke a tool?”

Then clarify:

> “The application team owns that semantic authorization. But the platform and security teams own whether the workload receives unlimited identity, credentials, filesystem access, and network reach while making that decision.”

### Transition

> “That shared ownership is the final message.”

## Slide 16 — Secure the AI workload, not only the model

### Purpose

End with a repeatable operating model.

### Core talk track

Deliver each line with a short pause:

> “Know what developers select.”

> “Know what the pipeline builds.”

> “Know what the artifact contains.”

> “Control what may deploy.”

> “Observe what actually runs.”

> “Limit what it can reach.”

> “Protect the AI decision boundary separately.”

Close with:

> “AI introduces new trust boundaries. A trusted software supply chain and runtime controls determine how far a bad decision can go.”

Do not end on the product architecture. End on the operating principle.

## Questions and answers bridge

Invite questions by role:

> “I am happy to go deeper on the developer workflow, RHTAP architecture, SBOM and RHTPA operations, RHACS policies and runtime evidence, or the AI-agent trust boundary.”

Useful short answers:

### “Does RHACS detect prompt injection?”

> “No. RHACS observes the container and Kubernetes consequences—such as processes, configuration, vulnerabilities, and network flows. The AI application must address the semantic authorization weakness.”

### “Does an SBOM include the model?”

> “Only if the model is actually represented in the scoped artifact and the chosen inventory format captures it. A remotely hosted model is not automatically part of the container SBOM. Treat model inventory as a related but separate evidence problem.”

### “Why use both RHTPA and RHACS?”

> “RHTPA operates composition and supply-chain risk knowledge over SBOMs. RHACS protects Kubernetes workloads across build, deploy, and runtime. They use related evidence for different decisions.”

### “Does NetworkPolicy fix the vulnerability?”

> “No. It limits the reachable consequence. The application still needs provenance-aware tool authorization and appropriate user confirmation.”

### “Why is the receiver inside the cluster?”

> “It keeps the demonstration bounded and repeatable while still showing a cross-namespace process and network consequence. Internal reachability is also a meaningful lateral-movement boundary.”

## Presenter discipline

- Say “AI workload” more often than the agent framework name.
- Say “RHACS observes the consequence” rather than “RHACS detects prompt injection.”
- Say “SBOM inventory” rather than “SBOM security guarantee.”
- Say “signature establishes provenance” rather than “signed means safe.”
- Say “RHTAP integrates the trusted path” rather than “RHTAP replaces every security product.”
- Keep the terminal as a trigger, not the presentation surface.
- Show the normal user experience before showing security telemetry.
- Separate application remediation from infrastructure containment.
