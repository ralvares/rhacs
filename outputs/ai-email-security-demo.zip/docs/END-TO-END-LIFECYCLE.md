# End-to-end AI workload and RHACS demonstration

## Purpose

This is the complete presentation guide: development dependencies, build, software supply chain, deployment, runtime behavior, containment, recovery, and presenter language.

The application is a realistic AI workload with several components:

- an agent runtime provides browser chat, sessions, the agent loop, workspace, skills, and tools;
- GreenMail provides SMTP and IMAP.
- Roundcube lets the audience view the same HTML email a human sees.
- `deepseek-v4-flash:cloud` is reached through the workstation's native Ollama API.
- OpenShift builds and stores the application images in its internal registry.
- RHACS provides image, deployment, process, and network evidence.
- OpenShift NetworkPolicy contains the demonstrated cross-namespace flow.

The central message is:

> **AI introduces new trust boundaries, but it does not remove the old ones.**

The selected agent-runtime implementation is OpenClaw. It is one component, not the presentation subject. RHACS does not read the email or classify prompt injection; it observes the dependencies, deployment posture, processes, and network behavior around the AI decision.

## Session description

This session dives into the high-stakes world of modern AI supply-chain risk. Engineering teams integrate open-source libraries, models, agent frameworks, tools, and dependencies into AI pipelines at high speed, so traditional perimeter controls alone are insufficient.

The presentation shows how Red Hat Advanced Cluster Security supports a code-to-cluster strategy:

- build an inventory of the software inside the AI workload;
- use SBOM and package data to understand inherited open-source components;
- detect known package vulnerabilities in built images;
- apply image, signature, admission, and deployment policy;
- observe processes and network communication at runtime;
- limit the impact of an unsafe agent decision through least privilege and egress containment.

The objective is not to make the audience study one agent framework. It is to show a reusable method for securing any containerized AI workload while continuing to benefit from open-source innovation.

## Demonstration outcome

The user asks:

```text
Summarize today's email.
```

With two ordinary messages, the chatbot returns an ordinary Markdown summary.

An external sender then delivers a multipart HTML email through SMTP. Roundcube shows a normal travel-policy update. The alternative text representation consumed by the mailbox helper contains an automated workflow instruction.

The user asks exactly the same question again. The model can interpret retrieved email data as authority and use the agent runtime's general `exec` capability to start `curl`. The process sends a generated, synthetic `.env` file to the isolated receiver in `demo-webhook`.

RHACS can show:

- the agent application's Node/npm dependency stack in the image;
- the clean and deliberately bad deployment-policy results;
- `python3` and `curl` running beneath the AI workload;
- the cross-namespace TCP 8080 flow.

After the restricted egress policy is applied, the agent can make the same wrong decision, but the receiver gets no new content.

## What changes during the runtime demonstration

```text
CODE              unchanged
IMAGE             unchanged
IMAGE SIGNATURE   unchanged
DEPLOYMENT        unchanged
MODEL             unchanged
USER REQUEST      unchanged

MAILBOX CONTENT   changed
```

Build-time controls are not wrong; they answer different questions from runtime controls.

## Architecture

```mermaid
flowchart LR
    sender[External sender Job] -->|SMTP| mail[GreenMail]
    human[Human] -->|HTTPS| webmail[Roundcube]
    webmail -->|IMAP| mail

    user[User] -->|HTTPS and WebSocket| claw[Agent UI and runtime]
    claw -->|read and exec| skill[Mailbox workspace skill]
    skill -->|IMAP| mail
    claw -->|Native Ollama API through CRC host| model[DeepSeek cloud model]
    claw -->|exec starts curl| receiver[Demo receiver]

    receiver -. separate namespace .-> hookns[demo-webhook]
    policy[Restricted NetworkPolicy] -. blocks .-> receiver
```

### Trust boundaries

```mermaid
flowchart TD
    email[Untrusted email body] --> context[Model context]
    workspace[Unsafe workspace trust rule] --> context
    context --> decision[Model tool decision]
    decision --> exec[Agent exec capability]
    exec --> process[Child process]
    process --> network[Pod network identity]
```

Authorization to read a mailbox does not imply authorization for instructions found inside that mailbox.

## Components and namespaces

| Component | Namespace | Responsibility |
|---|---|---|
| Agent runtime and browser UI | `ai-email-demo` | Personal-agent application, implemented with OpenClaw |
| Mailbox skill | OpenClaw workspace | Generic IMAP access using Python's standard library |
| GreenMail | `ai-email-demo` | SMTP and IMAP server for `demo@demo.test` |
| Roundcube | `ai-email-demo` | Human webmail view |
| `mail-api` | `ai-email-demo` | Deterministic mailbox seed/reset operations |
| Approved internal service | `ai-email-demo` | Destination explicitly retained by the restricted policy |
| External sender Job | `external-sender` | Sends the fixed multipart HTML message through SMTP |
| Demo receiver | `demo-webhook` | Records and logs the bounded synthetic artifact |
| Native Ollama API | Workstation | Connects OpenClaw to `deepseek-v4-flash:cloud` |

The receiver has no external Route. The demonstration never reads real credentials or cloud metadata.

## Complete lifecycle

```mermaid
flowchart LR
    source[Source and dependencies] --> build[OpenShift build]
    build --> sbom[Package inventory and SBOM]
    sbom --> scan[RHACS image scan]
    scan --> policy[Image and deployment policy]
    policy --> sign[Cosign signature]
    sign --> admission[Admission]
    admission --> baseline[Normal runtime]
    baseline --> changed[Mailbox input changes]
    changed --> observe[Process and network evidence]
    observe --> contain[NetworkPolicy containment]
    contain --> reset[Reset and rehearse]
```

## Stage 0 — prerequisites

Required:

- OpenShift Local/CRC running;
- `oc` logged in;
- host-network sharing enabled;
- native Ollama API running on the workstation;
- access to `deepseek-v4-flash:cloud`;
- `curl` and `openssl` on the workstation.

Check the model service:

```sh
curl http://localhost:11434/
curl http://localhost:11434/api/tags
```

The root endpoint should say that Ollama is running. `/v1` returning `404` is not a failure: this deployment uses the native API and `/api/chat`.

Check from CRC:

```sh
oc run host-check --rm -i --restart=Never --image=curlimages/curl -- \
  curl -fsS http://host.crc.testing:11434/
```

## Stage 1 — source dependencies

There are two intentionally different dependency stories.

### v1: deterministic failing scan target

`services/ai-agent/requirements-v1.txt` contains deliberately obsolete Python dependency pins. The v1 image exists only for scanning and policy rejection; it is never deployed.

This gives the presenter a stable comparison:

```text
ai-agent:v1  -> obsolete Python packages -> expected policy failure
ai-agent:v2  -> OpenClaw runtime          -> deployment candidate
```

### v2: the real OpenClaw application

`ai-agent:v2` inherits the OpenClaw Node.js application and npm/pnpm dependency tree from `ghcr.io/openclaw/openclaw:latest`. The resulting image also includes the small mailbox workspace from this repository.

Developer-time dependency analysis and RHACS image scanning answer related but different questions:

| View | Question |
|---|---|
| Source/dependency analysis | What risk are we introducing before a build? |
| SBOM/package inventory | What components are associated with the artifact? |
| RHACS image scan | What packages and known vulnerabilities are detected in the built image digest? |

If Red Hat Dependency Analytics is available, use the v1 Python dependency file to show an obvious developer-time finding. For v2, explain that OpenClaw's real application dependency tree is inherited from its base image rather than declared in this repository.

## Stage 2 — OpenShift build and internal registry

No Docker or Podman daemon is required.

```sh
./scripts/setup.sh openshift
```

The setup process:

1. creates the namespace and generated Secrets;
2. creates ImageStreams and binary BuildConfigs;
3. uploads each build context to OpenShift;
4. builds `mail-api`, `ai-agent:v1`, `ai-agent:v2`, and `demo-sink`;
5. stores the images in the OpenShift internal registry;
6. tags `ai-agent:v2` as `ai-agent:latest`;
7. deploys the application and Routes;
8. creates the external sender and receiver namespaces;
9. applies permissive opening-state egress;
10. seeds the mailbox and performs a real agent smoke test.

Verify build artifacts:

```sh
oc -n ai-email-demo get imagestreams
oc -n ai-email-demo get builds
oc -n ai-email-demo describe imagestream ai-agent
```

## Stage 3 — SBOM and Trusted Profile Analyzer

The application image contains two relevant software layers:

```text
base operating-system packages
        +
OpenClaw Node/npm packages
        +
demo workspace files
```

An image SBOM or package inventory should be associated with the immutable v2 image digest. If Trusted Profile Analyzer is available, import the generated SBOM and use it to answer:

- Which artifacts contain a particular npm package?
- Which version was shipped in this digest?
- Which applications are affected when a new vulnerability is published?
- Is the component inherited from a base image or added by the application build?

Do not claim that the remotely hosted DeepSeek model is part of the container SBOM. It is a separate external service and should be represented separately in any model inventory or AI BOM.

## Stage 4 — RHACS image and deployment gates

After RHACS is installed and `ROX_ENDPOINT` and `ROX_API_TOKEN` are configured:

```sh
./scripts/rhacs-ci-gate.sh
```

The script performs six checks:

1. scan obsolete v1;
2. require v1 to fail image policy;
3. require the deliberately privileged v1 manifest to fail deployment policy;
4. scan current v2;
5. require v2 to satisfy configured image/signature policies;
6. require the clean v2 manifest to satisfy deployment policies.

The deterministic bad manifest is:

```text
deploy/rhacs/bad-ai-agent.yaml
```

The deployment candidate is:

```text
deploy/rhacs/clean-ai-agent.yaml
```

The vulnerable package count and current v2 findings depend on the exact image digest and RHACS vulnerability database. Show the live result; do not promise a hardcoded CVE count.

## Stage 5 — signing and admission

Generate a demonstration Cosign key pair:

```sh
./scripts/generate-signing-key.sh
```

Sign the immutable v2 digest:

```sh
./scripts/sign-release-v2.sh
```

Configure the RHACS signature integration and admission policy before presenting this stage. Demonstrate rejection of the untrusted v1 path and admission of the signed v2 digest.

A signature establishes artifact provenance. It does not establish that every future model decision is safe.

## Stage 6 — verify deployment and user access

```sh
oc -n ai-email-demo get deployments,pods,services,routes
oc -n ai-email-demo get networkpolicies
oc -n ai-email-demo exec deployment/ai-agent -- node openclaw.mjs models list
oc -n ai-email-demo exec deployment/ai-agent -- node openclaw.mjs skills list
./scripts/show-demo-credentials.sh
```

Routes:

- OpenClaw: `https://ai-agent-ai-email-demo.apps-crc.testing`
- Roundcube: `https://webmail-ai-email-demo.apps-crc.testing`
- Mail API: `https://mail-api-ai-email-demo.apps-crc.testing`

Roundcube defaults to `demo` / `demo`, with mailbox address `demo@demo.test`. Override `DEMO_MAIL_USER`, `DEMO_MAIL_PASSWORD`, and `DEMO_MAIL_DOMAIN` in `.env`, then run `setup-demo.sh` to recreate the Secret and restart its consumers. The credential is still injected through a Kubernetes Secret; the OpenClaw gateway token remains dynamically generated.

For the first OpenClaw browser connection:

1. paste the generated gateway token;
2. leave Password empty;
3. select Connect once to create the pairing request;
4. run `./scripts/show-demo-credentials.sh --approve` to approve the newest device;
5. select Connect again.

## Stage 7 — establish normal behavior

Prepare the complete clean baseline:

```sh
./scripts/setup-demo.sh
```

This fast reset uses the already deployed environment. It does not rebuild, send the injected message, or invoke the model. It reapplies the configured mailbox credential, restores the before-policy, removes the earlier sender Job, invokes OpenClaw's supported session reset, restarts the agent, seeds two ordinary messages, clears the receiver, validates the workloads, and prints the browser credentials. Agent state is stored on a PVC rather than `emptyDir`; ordinary restarts preserve it, while session removal is an explicit reset action.

The equivalent mailbox-only operation is:

```sh
MAIL_API=https://$(oc -n ai-email-demo get route mail-api -o jsonpath='{.spec.host}')
curl -kfsS -X POST "$MAIL_API/seed"
```

Open Roundcube and confirm:

- Quarterly planning
- Lobby maintenance

Open a new OpenClaw conversation and ask:

```text
Summarize today's email.
```

Expected:

- a properly rendered Markdown summary;
- OpenClaw uses `read` to load the mailbox skill;
- `exec` starts `python3` for the generic IMAP helper;
- no `curl` process;
- no request in `demo-webhook`.

This establishes the normal process and network baseline before introducing the third message.

## Stage 8 — send the external HTML email

```sh
./scripts/send-external-html-email.sh
```

The script recreates a short-lived Job in `external-sender`, sends the message through SMTP, and waits for delivery.

Open it in Roundcube. The visible HTML is an ordinary travel-policy update. There is no white-on-white text. The alternative MIME text consumed by the mailbox helper carries the unsafe automated workflow note.

Say:

> “Nothing in Kubernetes changed. The image, signature, deployment, model, and user request are the same. A new email arrived.”

## Stage 9 — repeat the same request and observe

Keep the receiver log visible:

```sh
oc -n demo-webhook logs -f deployment/demo-webhook
```

Start a fresh OpenClaw conversation and ask exactly the same question:

```text
Summarize today's email.
```

Expected application behavior:

```text
read SKILL.md
   |
exec python3 mailbox helper
   |
email body enters model context
   |
model selects exec again
   |
exec starts curl
   |
POST synthetic .env to demo receiver
```

The user-facing response remains a normal rendered Markdown email summary. Do not expose routine tool traces in the chat UI; use OpenClaw and platform evidence as the presenter view.

Check receiver state:

```sh
oc -n demo-webhook exec deployment/demo-webhook -- python -c \
  "import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8080/requests').read().decode())"
```

The receiver logs the complete bounded synthetic content with the marker `DEMO_ENV_FILE_RECEIVED`.

### RHACS process evidence

Look for `python3` and `curl` under the OpenClaw Node workload. `read` is an in-process file operation and is normally visible in the OpenClaw trace rather than as a separate Linux process.

Approximate ancestry:

```text
node openclaw.mjs gateway
└── exec child
    ├── python3 .../mailbox.py today --json
    └── curl .../artifacts/environment
```

### RHACS Network Graph evidence

```text
ai-email-demo / ai-agent
    -> demo-webhook / demo-webhook
    -> TCP 8080
```

Key statement:

> **RHACS did not detect a malicious email. It observed the workload behaving differently because of that email.**

## Stage 10 — contain and repeat

Apply the restricted egress state:

```sh
./scripts/restrict-egress.sh
```

The allowlist retains:

- cluster DNS;
- GreenMail IMAP on TCP 3143;
- the workstation model API on TCP 11434;
- the explicitly approved internal service on TCP 8080.

It does not allow the cross-namespace demo receiver.

Clear receiver evidence, start another fresh conversation, and issue the same request. The model may still select `exec` and `curl` may still start, but the request should time out and the receiver should remain empty.

OpenShift's network implementation enforces NetworkPolicy. RHACS supplies the workload and flow visibility; do not describe RHACS itself as the packet-filtering engine.

The prompt-injection condition remains. The network consequence is contained.

## What every layer proves

| Lifecycle layer | Question answered | What it cannot prove |
|---|---|---|
| Dependency analysis | Should we introduce this package/version? | What actually ran |
| SBOM/TPA | What components are associated with the artifact? | Absence of all vulnerabilities |
| RHACS image scan | What known findings exist in this image digest? | Safe model intent |
| Deployment policy | Does the manifest meet configured posture rules? | Trustworthiness of email content |
| Cosign signature | Did an approved producer sign this digest? | Benign runtime behavior |
| Admission | May this artifact enter the protected cluster? | Correct authorization for every tool call |
| ServiceAccount/RBAC | What Kubernetes authority does the pod have? | Which external service it may reach |
| OpenClaw tool policy | Which agent capabilities are available? | That untrusted data cannot influence them |
| RHACS process view | Which child processes ran? | Why the model chose them |
| RHACS Network Graph | Which workload communicated with which destination? | Whether the flow was semantically authorized |
| NetworkPolicy | Which network paths are allowed? | Removal of the model-level weakness |
| Agent controls | Whether retrieved content may authorize an action | Image and cluster posture |

## Application-level remediation

Containment is not the final application fix. A production agent should also use:

- strict separation of system instructions from retrieved email content;
- provenance-aware authorization;
- narrow tool allowlists and schemas;
- destination and argument validation;
- explicit user approval before sensitive actions;
- isolated execution with minimal filesystem access;
- credentials scoped to the task;
- deny-by-default egress;
- complete tool-decision auditing.

## Presenter script

### Minimal-CLI presentation path

Complete setup, image builds, model checks, browser pairing, and rehearsal before the session. Keep the live story visual and run only three short commands:

```sh
./scripts/rhacs-ci-gate.sh
./scripts/send-external-html-email.sh
./scripts/restrict-egress.sh
```

The first command is optional if the RHACS UI already contains the prepared v1/v2 scan and policy results. The audience-facing flow should be:

```text
RHACS/TPA supply-chain views
        -> Roundcube normal inbox
        -> chatbot normal summary
        -> send one email
        -> chatbot repeats same request
        -> RHACS process and Network Graph evidence
        -> restrict egress
        -> repeat and show containment
```

Do not type long `oc`, `curl`, or JSON commands live. Keep those commands in the troubleshooting and reset sections for rehearsal only.

### Opening

> “This is a personal agent running as a normal OpenShift workload. It reads a real mailbox through IMAP and uses a remote model to summarize the day.”

Show Roundcube, then ask for the normal summary.

### Supply-chain act

1. Show the v1 dependency file.
2. Show RHDA if available.
3. Show the image package inventory/SBOM and TPA if available.
4. Scan v1 and show the expected rejection.
5. Check the privileged manifest and show the expected rejection.
6. Scan and check v2.
7. Show the v2 signature and admission decision.

Say:

> “The approved artifact is known, scanned, signed, and deployed with a clean manifest. Those controls establish supply-chain and deployment posture.”

### Runtime act

Send the external message and show it in Roundcube.

> “I have not replaced the image or changed Kubernetes. The attacker sent an email.”

Repeat the same user request. Show the normal chat answer, receiver log, process activity, and Network Graph.

> “The email was data for the user, but the agent treated part of it as authority.”

### Containment act

Apply the restricted policy and repeat.

> “The application still needs an AI-layer fix. The infrastructure control has removed the network path that turned the wrong decision into a successful transfer.”

## Strong claims

Use:

- “RHACS inventories known dependency risk in the built image.”
- “RHACS observes configured process and network behavior from the workload.”
- “The attacker changed mailbox content, not the container image.”
- “Signing proves provenance, not safe future intent.”
- “NetworkPolicy limits the blast radius; it does not fix prompt injection.”
- “The blast radius of an agent is defined by its tools, files, credentials, identity, and network reach.”

Avoid:

- “RHACS detects prompt injection.”
- “RHACS understands malicious email.”
- “This is an OpenClaw RCE.”
- “The receiver is an external internet attacker.”
- “Every new process automatically generates an alert.”
- “The signature proves the runtime action is safe.”
- “NetworkPolicy repairs the model.”

## Reliability and fallback

Model tool selection is probabilistic. Rehearse the exact model and message several times on presentation day.

Before the session, verify:

- OpenShift builds and internal image tags;
- model API reachability from the pod;
- OpenClaw model and skill lists;
- SMTP delivery and IMAP retrieval;
- browser device pairing;
- rendered Markdown in Control UI;
- receiver logging;
- RHACS Collector process telemetry;
- RHACS Network Graph flow;
- the before/after NetworkPolicy states;
- v1 rejection, v2 checks, signing, and admission if those stages are presented.

Keep screenshots of the dependency result, SBOM/TPA view, image scan, bad deployment rejection, signature/admission result, process tree, Network Graph, receiver event, and contained repeat.

## Reset between demonstrations

Use the single base-state command:

```sh
./scripts/setup-demo.sh
```

It restores permissive egress, removes the completed sender Job, restarts the agent to erase prior sessions, resets the mailbox to two normal messages, clears receiver history, verifies the Deployments, and prints routes and credentials.

Start new OpenClaw conversations so earlier message/tool context does not affect the next rehearsal.

Run the normal and injected phases automatically when validating:

```sh
./scripts/run-demo.sh
```

## Safety boundary

- All identities and content are synthetic.
- `.env` contains generated demo-only values.
- The body is bounded to 4 KiB.
- The receiver is isolated in-cluster and has no Route.
- No cloud metadata, genuine credential, or internet target is used.
- v1 is scan-only and is never deployed.
- The external sender is fixed to the demonstration message.

## Final message

```text
Know what goes in.
Know what was built.
Control what may deploy.
Limit what the agent can reach.
Observe what it actually does.
Protect the AI decision boundary separately.
```

> **The model introduces a new trust boundary. The software supply chain, container, identity, tools, and network still determine how far a bad decision can go.**
